

<?php echo $__env->make('layouts/auth', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!DOCTYPE html>
<html lang="en" dir="ltr">

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<title><?php echo $__env->yieldContent('title'); ?></title>
	<link type="text/css" href="assets/css/vendor-morris.css" rel="stylesheet">
	<link type="text/css" href="assets/css/vendor-bootstrap-switch.css" rel="stylesheet">
	<link type="text/css" href="assets/css/vendor-bootstrap-datepicker.css" rel="stylesheet">
	<link type="text/css" href="assets/vendor/simplebar.css" rel="stylesheet">
	<!-- Prevent the demo from appearing in search engines -->
	<meta name="robots" content="noindex">
	<!-- App CSS -->
	<link type="text/css" href="<?php echo e(asset('/assets/css/app.css')); ?>" rel="stylesheet">
	<link type="text/css" href="<?php echo e(asset('/assets/css/app.rtl.css')); ?>" rel="stylesheet">
	<link type="text/css" href="<?php echo e(asset('/assets/css/matryk-style.css')); ?>" rel="stylesheet">
	<link type="text/css" href="<?php echo e(asset('/assets/css/kokitindo.css')); ?>" rel="stylesheet">
    <!-- vendor external -->

	<!-- Simplebar -->
	<link type="text/css" href="<?php echo e(asset('/assets/vendor/simplebar.css')); ?>" rel="stylesheet">
	<link type="text/css" href="<?php echo e(asset('/assets/vendor/stylekokitindo.css')); ?>" rel="stylesheet">

	
	<?php echo $__env->yieldContent('css'); ?>

</head>

<body>
	<div class="mdk-drawer-layout js-mdk-drawer-layout" data-fullbleed data-push data-responsive-width="992px" data-has-scrolling-region>
		<div class="mdk-drawer-layout__content">
			<!-- header-layout -->
			<div class="mdk-header-layout js-mdk-header-layout  mdk-header--fixed  mdk-header-layout__content--scrollable">
				<!-- header -->
				<?php echo $__env->make('layouts/assets/header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
				

				<!-- content -->
				<div class="mdk-header-layout__content top-navbar mdk-header-layout__content--scrollable h-100">
					<!-- main content -->
					<div class="container-fluid">
						<?php echo $__env->yieldContent('content'); ?>
					</div>
				</div>


			</div>

		</div>

		<!-- Drawer -->
		<?php echo $__env->make('layouts/assets/maindrawer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		<?php echo $__env->make('layouts/assets/footdrawer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		<!-- // END drawer-layout__content -->

	</div>

	<!-- jQuery -->
	<script src="<?php echo e(asset('/assets/vendor/jquery.min.js')); ?>"></script>
	<!-- Bootstrap -->
	<script src="<?php echo e(asset('/assets/vendor/popper.js')); ?>"></script>
	<script src="<?php echo e(asset('/assets/vendor/bootstrap.min.js')); ?>"></script>
	<!-- Simplebar -->
	<!-- Used for adding a custom scrollbar to the drawer -->
	<script src="<?php echo e(asset('/assets/vendor/simplebar.js')); ?>"></script>
	<!-- Vendor -->
	<script src="<?php echo e(asset('/assets/vendor/Chart.min.js')); ?>"></script>
	<script src="<?php echo e(asset('/assets/vendor/moment.min.js')); ?>"></script>
	<!-- APP -->
	<script src="<?php echo e(asset('/assets/js/color_variables.js')); ?>"></script>
	<script src="<?php echo e(asset('/assets/js/app.js')); ?>"></script>
	<script src="<?php echo e(asset('/assets/vendor/dom-factory.js')); ?>"></script>
	<!-- DOM Factory -->
	<script src="<?php echo e(asset('/assets/vendor/material-design-kit.js')); ?>"></script>
	<script src="<?php echo e(asset('/assets/vendor/select2.full.min.js')); ?>"></script>

    <script>
        $('.select-2').select2({
            theme: 'bootstrap',
            placeholder: 'Select an option'
        });
    </script>
   
    <script src="<?php echo e(asset('/assets/vendor/morris.min.js')); ?>"></script>
    <script src="<?php echo e(asset('/assets/vendor/raphael.min.js')); ?>"></script>
    <script src="<?php echo e(asset('/assets/vendor/bootstrap-datepicker.min.js')); ?>"></script>
    <script src="<?php echo e(asset('/assets/js/datepicker.js')); ?>"></script>
    <!-- sweetaleret -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@8"></script>
    <!-- data table -->
    <script src="<?php echo e(asset('/assets/vendor/jquery.dataTables.js')); ?>"></script>
	<script src="<?php echo e(asset('/assets/vendor/dataTables.bootstrap4.js')); ?>"></script>
	

    <?php echo $__env->yieldContent('js'); ?>
    <script>
        (function() {
            'use strict';
            // Self Initialize DOM Factory Components
            domFactory.handler.autoInit()


            // Connect button(s) to drawer(s)
            var sidebarToggle = document.querySelectorAll('[data-toggle="sidebar"]')

            sidebarToggle.forEach(function(toggle) {
                toggle.addEventListener('click', function(e) {
                    var selector = e.currentTarget.getAttribute('data-target') || '#default-drawer'
                    var drawer = document.querySelector(selector)
                    if (drawer) {
                        if (selector == '#default-drawer') {
                            $('.container-fluid').toggleClass('container--max');
                        }
                        drawer.mdkDrawer.toggle();
                    }
                })
            })
        })()
    </script>


    <script src="assets/vendor/bootstrap-switch.min.js"></script>

    <script>
        $("input[name='bootstrap-switch']").bootstrapSwitch();
    </script>

</body>

</html>