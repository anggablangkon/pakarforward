<?php if(Session::get('id') == false): ?>
	<meta http-equiv="refresh" content="0; url=<?php echo e(url('/')); ?>">
<?php endif; ?>