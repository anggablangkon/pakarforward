 <!-- drawer -->
            <div class="mdk-drawer js-mdk-drawer" id="user-drawer" data-position="right" data-align="end">
              <div class="mdk-drawer__content">
                <div class="mdk-drawer__inner" data-simplebar data-simplebar-force-enabled="true">
                  <nav class="drawer drawer--light">
                    <div class="drawer-spacer drawer-spacer-border">
                      <div class="media align-items-center">
                        <div class="media-body">
                          <a href="#" class="h5 m-0"><?php echo e(Session::get('nama')); ?></a>
                          <div>
                            <?php if(Session::get('hakakses') == 1): ?> Menu Pengguna Sistem  <?php endif; ?>
                            <?php if(Session::get('hakakses') == 2): ?> Menu Pasien <?php endif; ?>
                          </div>
                        </div>
                      </div>
                    </div>
                   
                    <!-- MENU -->
                    <ul class="drawer-menu" id="userMenu" data-children=".drawer-submenu">
                      
                      <li class="drawer-menu-item">
                        <a href="<?php echo e(url('/logout')); ?>">
                          <i class="material-icons">exit_to_app</i>
                          <span class="drawer-menu-text" style="color: black;"> Keluar </span>
                        </a>
                      </li>
                    </ul>
                  </nav>
                </div>
              </div>
            </div>
            <!-- // END drawer -->